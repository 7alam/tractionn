package com.example.projecct.fragment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBhelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "contacts.db";
    private static final String TABLE_NAME = "contacts";
    private static final String COL_1 = "NAME";   // Name column

    private static final String COL_2 = "EMAIL";  // Email column
    private static final String COL_3 = "PHONE";  // Phone column
    private static final String COL_4 = "CAR";    // Car column

    public DBhelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create contacts table
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "NAME TEXT, EMAIL TEXT, PHONE TEXT, CAR TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert data method
    public boolean insertData(String name, String car, String phone, String email) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, name);
        contentValues.put(COL_2, email);
        contentValues.put(COL_3, phone);
        contentValues.put(COL_4, car);

        try {
            long result = db.insert(TABLE_NAME, null, contentValues);
            if (result == -1) {
                Log.e("DBHelper", "Failed to insert data: " + name + ", " + phone);
                return false; // Return false if insert failed
            } else {
                return true; // Inserted successfully
            }
        } catch (Exception e) {
            Log.e("DBHelper", "Error during insert: " + e.getMessage());
            return false;
        }
    }

    // Delete data by user name
// Modify the method to delete by car name, not by user name


    public boolean deleteUser(String userName) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Delete a record from the database where the user name matches
        int result = db.delete(TABLE_NAME, COL_1 + " = ?", new String[]{userName});  // Use COL_2 for NAME column

        // Log the result for debugging
        if (result > 0) {
            Log.d("DBHelper", "customer deleted successfully: " + userName);
            return true;
        } else {
            Log.e("DBHelper", "No user found with the name: " + userName);
            return false; // No rows deleted, possible name mismatch or not found
        }
    }

    // Retrieve all contacts from the database
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

}
