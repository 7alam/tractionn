package com.example.projecct.fragment;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.projecct.R;

public class lambo extends Fragment {

    private ImageButton imageButtonGoToVichle;  // Declare ImageButton
    private Button buttonDatabase1, buttonDatabase2, buttonDatabase3, buttonDatabase4;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.lambo, container, false);

        // Find the ImageButton by its ID
        imageButtonGoToVichle = view.findViewById(R.id.button4);

        // Initialize the buttons for database navigation
        buttonDatabase1 = view.findViewById(R.id.button_lambo);
        buttonDatabase2 = view.findViewById(R.id.button_lambo1);
        buttonDatabase3 = view.findViewById(R.id.button_lambo2);
        buttonDatabase4 = view.findViewById(R.id.button_lambo3);

        // Set a click listener for the ImageButton (go to Vehicle fragment)
        imageButtonGoToVichle.setOnClickListener(v -> {
            // Replace the current fragment with the Vehicle fragment
            FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, new Vichle());
            transaction.addToBackStack(null);  // Add to back stack so the user can navigate back
            transaction.commit();
        });

        // Set onClickListeners for the buttons that navigate to the database fragment
        buttonDatabase1.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase2.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase3.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase4.setOnClickListener(v -> navigateToDatabasePage());

        return view;
    }

    private void navigateToDatabasePage() {
        // Navigate to the database fragment
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, new database());  // Replace with your database fragment
        transaction.addToBackStack(null);  // Add to back stack so the user can navigate back
        transaction.commit();
    }
}
