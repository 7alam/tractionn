package com.example.projecct.fragment;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.projecct.R;

public class Vichle extends Fragment {

    private View view;
    private Button button, button2, button3;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_vichle, container, false);

        // Find the buttons by their IDs
        button = view.findViewById(R.id.button);
        button2 = view.findViewById(R.id.button2);
        button3 = view.findViewById(R.id.button3);


        // Set click listeners for each button
        button.setOnClickListener(v -> navigateToFragment(new lambo()));
        button3.setOnClickListener(v -> navigateToFragment(new mer()));
        button2.setOnClickListener(v -> navigateToFragment(new bmw()));


        return view;
    }

    // Utility method to navigate to a fragment
    private void navigateToFragment(Fragment fragment) {
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment); // Replace the fragment in the container
        transaction.addToBackStack(null); // Optionally add to back stack for navigation back
        transaction.commit(); // Commit the transaction
    }
}
