package com.example.projecct.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.Toast;  // Import Toast class
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.example.projecct.R;

public class bmw extends Fragment {

    private ImageButton imageButtonGoToVichle;  // Declare ImageButton
    private Button buttonDatabase1, buttonDatabase2, buttonDatabase3, buttonDatabase4;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.bmw, container, false);

        // Find the ImageButton by its ID (button6)
        imageButtonGoToVichle = view.findViewById(R.id.button6);

        // Find the Buttons for Toast (buttonNotify, buttonNotify2, buttonNotify3, buttonNotify4)
        buttonDatabase1 = view.findViewById(R.id.button_car1);
        buttonDatabase2 = view.findViewById(R.id.button_car2);
        buttonDatabase3 = view.findViewById(R.id.button_car3);
        buttonDatabase4 = view.findViewById(R.id.button_car4);
        // Set an OnClickListener to the ImageButton to navigate to Vichle
        imageButtonGoToVichle.setOnClickListener(v -> {
            // Replace the current fragment with the Vichle fragment
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, new Vichle());
            transaction.addToBackStack(null);  // Add to back stack so the user can navigate back
            transaction.commit();
        });

        // Set an OnClickListener to each button to show different Toast messages
        // Set onClickListeners for the buttons that navigate to the database page
        buttonDatabase1.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase2.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase3.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase4.setOnClickListener(v -> navigateToDatabasePage());
        return view;
    }

    // Method to show a Toast with a custom message
    private void navigateToDatabasePage() {
        // Navigate to the database fragment
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, new database());  // Replace with your database fragment
        transaction.addToBackStack(null);  // Add to back stack so the user can navigate back
        transaction.commit();
    }
}
