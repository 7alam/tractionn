package com.example.projecct.fragment;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;  // Import Button
import com.example.projecct.R;

public class AboutUs extends Fragment {

    private Button buttonGoToVichle;  // Declare Button

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_about_us, container, false);

        // Find the Button by its ID (button_go_to_vichle)
        buttonGoToVichle = view.findViewById(R.id.button7);

        // Set an OnClickListener for the Button
        buttonGoToVichle.setOnClickListener(v -> {
            // Start the Vichle fragment
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, new Vichle());
            transaction.addToBackStack(null);  // Add to back stack so the user can navigate back
            transaction.commit();
        });

        return view;
    }
}




