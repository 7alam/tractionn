package com.example.projecct.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.projecct.R;
import com.example.projecct.ViewContactsActivity;  // Ensure you import the correct activity

public class database extends Fragment {

    private DBhelper myDb;

    public database() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.database1, container, false);

        // Initialize the DBhelper (make sure to initialize the database object)
        myDb = new DBhelper(requireContext());

        // Back button functionality
        ImageButton btnBack = view.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> {
            // This will pop the current fragment from the back stack (go back to the previous fragment)
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        // View Database button functionality (navigate to ViewContactsActivity)
        Button btnViewDatabase = view.findViewById(R.id.btnViewDatabase);
        btnViewDatabase.setOnClickListener(v -> {
            try {
                // Explicit intent to navigate to ViewContactsActivity
                if (getActivity() != null) {
                    Intent intent = new Intent(getActivity(), ViewContactsActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getActivity(), "Activity context is not available", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getActivity(), "Error navigating to View Database", Toast.LENGTH_SHORT).show();
            }
        });

        // Add User functionality
        Button btnAddUser = view.findViewById(R.id.btnAddUser);
        btnAddUser.setOnClickListener(v -> {
            // Collect data from EditText fields
            EditText etName = view.findViewById(R.id.etName);
            EditText etEmail = view.findViewById(R.id.etEmail);
            EditText etPhone = view.findViewById(R.id.etPhone);
            EditText etCarName = view.findViewById(R.id.etCarName);

            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String carName = etCarName.getText().toString().trim();

            // Add user to the database
            if (!name.isEmpty() && !email.isEmpty() && !phone.isEmpty() && !carName.isEmpty()) {
                boolean isInserted = myDb.insertData(name, email, phone, carName); // Call the proper insertData method in DBhelper
                if (isInserted) {
                    Toast.makeText(getActivity(), "the purchase have been done Successfully!", Toast.LENGTH_SHORT).show();
                    // Clear the EditText fields after adding
                    etName.setText("");
                    etEmail.setText("");
                    etPhone.setText("");
                    etCarName.setText("");
                } else {
                    Toast.makeText(getActivity(), "Failed to buy car", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getActivity(), "All fields are required", Toast.LENGTH_SHORT).show();
            }
        });

        // Delete Car functionality


        // Delete User functionality (Fixed the button handling and logic)
        Button btnDeleteUser = view.findViewById(R.id.btnDeleteUser);
        btnDeleteUser.setOnClickListener(v -> {
            // Collect user name from EditText
            EditText etName = view.findViewById(R.id.etName); // Assuming user name is the same as the car name input field
            String userName = etName.getText().toString().trim();

            // Delete user from the database
            if (!userName.isEmpty()) {
                boolean isDeleted = myDb.deleteUser(userName); // Call the deleteUser method to delete based on user name
                if (isDeleted) {
                    Toast.makeText(getActivity(), "customer Deleted Successfully!", Toast.LENGTH_SHORT).show();
                    etName.setText(""); // Clear the EditText after deleting
                } else {
                    Toast.makeText(getActivity(), "Failed to Delete customer", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getActivity(), "User name is required", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
