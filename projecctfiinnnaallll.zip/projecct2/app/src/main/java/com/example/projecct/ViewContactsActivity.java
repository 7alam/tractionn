package com.example.projecct;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projecct.fragment.DBhelper;

public class ViewContactsActivity extends AppCompatActivity {

    private DBhelper myDb;
    private TextView textView;
    private EditText editFilter;

    private static final String TAG = "ViewContactsActivity"; // For logging

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_contacts);

        // Initialize database helper
        myDb = new DBhelper(this);

        // Initialize views
        textView = findViewById(R.id.textViewContacts);
        editFilter = findViewById(R.id.editFilter);

        // Display all contacts on launch
        Cursor cursor = myDb.getAllData();
        displayContacts(cursor);
    }


    // Display contacts in the TextView
    private void displayContacts(Cursor cursor) {
        if (cursor == null || cursor.getCount() == 0) {
            textView.setText("No contacts found.");
            return;
        }

        StringBuilder builder = new StringBuilder();
        while (cursor.moveToNext()) {
            builder.append("ID: ").append(cursor.getString(0)).append("\n");
            builder.append("Name: ").append(cursor.getString(1)).append("\n");
            builder.append("Email: ").append(cursor.getString(2)).append("\n");
            builder.append("Phone: ").append(cursor.getString(3)).append("\n");
            builder.append("Car: ").append(cursor.getString(4)).append("\n");
            builder.append("----------------------------------------\n");
        }
        textView.setText(builder.toString());
    }
}
