package com.example.projecct.fragment;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.projecct.R;

public class mer extends Fragment {

    private ImageButton imageButtonGoToVichle;  // Declare ImageButton
    private Button buttonDatabase1, buttonDatabase2, buttonDatabase3, buttonDatabase4;
    private Button buttonNotify, buttonNotify2, buttonNotify3, buttonNotify4;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.mer, container, false);

        // Find the ImageButton by its ID
        imageButtonGoToVichle = view.findViewById(R.id.button5);
        buttonDatabase1 = view.findViewById(R.id.button_car1);
        buttonDatabase2 = view.findViewById(R.id.button_car2);
        buttonDatabase3 = view.findViewById(R.id.button_car3);
        buttonDatabase4 = view.findViewById(R.id.button_car4);
        // Set a click listener for the ImageButton
        imageButtonGoToVichle.setOnClickListener(v -> {
            // Replace the current fragment with the Vichle fragment
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, new Vichle());
            transaction.addToBackStack(null);  // Add to back stack so the user can navigate back
            transaction.commit();
        });
        buttonDatabase1.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase2.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase3.setOnClickListener(v -> navigateToDatabasePage());
        buttonDatabase4.setOnClickListener(v -> navigateToDatabasePage());

        return view;
    }
    private void navigateToDatabasePage() {
        // Navigate to the database fragment
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, new database());  // Replace with your database fragment
        transaction.addToBackStack(null);  // Add to back stack so the user can navigate back
        transaction.commit();
    }
}
