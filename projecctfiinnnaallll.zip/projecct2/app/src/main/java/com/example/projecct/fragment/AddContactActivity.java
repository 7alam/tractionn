package com.example.projecct.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projecct.R;

public class AddContactActivity extends AppCompatActivity {

        DBhelper myDb;
        EditText editName, editPhone, editEmail, editCarName; // Corrected car_name to editCarName

        @SuppressLint("MissingInflatedId")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.add_contact_activity);
                myDb = new DBhelper(this);

                // Initialize UI elements
                editName = findViewById(R.id.editTextName);
                editEmail = findViewById(R.id.editTextEmail);
                editPhone = findViewById(R.id.editTextPhone);
                editCarName = findViewById(R.id.editTextcar_name); // Corrected editcar_name to editCarName
        }

        // Method to save the contact to the database
        public void saveContact(View view) {
                String name = editName.getText().toString().trim();
                String email = editEmail.getText().toString().trim();
                String phone = editPhone.getText().toString().trim();
                String carName = editCarName.getText().toString().trim(); // Use editCarName here instead of car_name

                Log.d("AddContactActivity", "Name: " + name +  ", Email: " + email + ", Phone: " + phone +", Car Name: " + carName);

                // Check if any field is empty before trying to save
                if (name.isEmpty() ||email.isEmpty()  ||  phone.isEmpty()|| carName.isEmpty()) {
                        Toast.makeText(this, "All fields must be filled", Toast.LENGTH_SHORT).show();
                        return; // Don't proceed if any field is empty
                }

                // Insert data into the database
                boolean isInserted = myDb.insertData(name, email, phone, carName);

                if (isInserted) {
                        Toast.makeText(this, "Contact Added", Toast.LENGTH_SHORT).show();
                } else {
                        Toast.makeText(this, "Error Adding Contact", Toast.LENGTH_SHORT).show();
                }
        }
}
